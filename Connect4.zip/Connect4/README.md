CONNECT 4

Simple, classic, time-honored game most often played while waiting for a table at the Cracker Barrel or in the waiting room of your friendly neighborhood dentist.

As the name implies, connect four of the same colored discs horizontally, vertically, or diagonally before your opponent does and WIN! And then eat.  Or get your cavity filled.  With Connect 4 the possibilities are....well, not endless, but you'll have fun.